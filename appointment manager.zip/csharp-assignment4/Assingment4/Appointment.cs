namespace Assignment4;

// Stores all data for one appointment.
public class Appointment
{
    // Backing fields keep the class in control of its own data.
    private string firstName = string.Empty;
    private string lastName = string.Empty;
    private DateTime appointmentDateTime;
    private VisitType visitType;
    private CareType careType;
    private string notes = string.Empty;

    // Creates an appointment with the required values.
    public Appointment(string firstName, string lastName, DateTime appointmentDateTime)
    {
        FirstName = firstName;
        LastName = lastName;
        AppointmentDateTime = appointmentDateTime;
        VisitType = VisitType.RoutineCheck;
        CareType = CareType.Doctor;
        Notes = string.Empty;
    }

    // First name must not be empty.
    public string FirstName
    {
        get { return firstName; }
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("First name cannot be empty.");
            }

            firstName = value.Trim();
        }
    }

    // Last name must not be empty.
    public string LastName
    {
        get { return lastName; }
        set
        {
            if (string.IsNullOrWhiteSpace(value))
            {
                throw new ArgumentException("Last name cannot be empty.");
            }

            lastName = value.Trim();
        }
    }

    // Stores the appointment date and time.
    public DateTime AppointmentDateTime
    {
        get { return appointmentDateTime; }
        set { appointmentDateTime = value; }
    }

    // Stores the type of visit.
    public VisitType VisitType
    {
        get { return visitType; }
        set { visitType = value; }
    }

    // Stores the type of care provider.
    public CareType CareType
    {
        get { return careType; }
        set { careType = value; }
    }

    // Stores optional notes.
    public string Notes
    {
        get { return notes; }
        set
        {
            if (value is null)
            {
                notes = string.Empty;
                return;
            }

            notes = value.Trim();
        }
    }

    // Returns one readable line for the GUI list.
    public override string ToString()
    {
        string noteText = string.Empty;
        if (!string.IsNullOrWhiteSpace(Notes))
        {
            noteText = " | Notes: " + Shorten(Notes, 25);
        }

        return $"{AppointmentDateTime:yyyy-MM-dd HH:mm} | {FirstName} {LastName} | {VisitType} | {CareType}{noteText}";
    }

    // Keeps long notes short in the list box.
    private static string Shorten(string text, int maxLength)
    {
        if (text.Length <= maxLength)
        {
            return text;
        }

        return text[..maxLength] + "...";
    }
}
