namespace Assignment4;

// Stores and manages appointments in one fixed-size array.
public class BookingManager
{
    // The fixed array required by the assignment.
    private readonly Appointment?[] appointments;

    // Tracks how many appointments are currently stored.
    private int numOfElements;

    // Creates the internal array with the requested size.
    public BookingManager(int size)
    {
        if (size <= 0)
        {
            throw new ArgumentOutOfRangeException(nameof(size), "Array size must be greater than zero.");
        }

        appointments = new Appointment?[size];
        numOfElements = 0;
    }

    // Gives the current number of stored appointments.
    public int Count
    {
        get { return numOfElements; }
    }

    // Gives the maximum number of appointments that can be stored.
    public int Capacity
    {
        get { return appointments.Length; }
    }

    // Adds a ready-made appointment object to the array.
    public bool Add(Appointment appointment)
    {
        // Reject null and reject add when array is already full.
        if (appointment is null || numOfElements >= appointments.Length)
        {
            return false;
        }

        appointments[numOfElements] = appointment;
        numOfElements++;
        return true;
    }

    // Adds an appointment by creating it from individual values.
    public bool Add(string firstName, string lastName, DateTime dateTime, VisitType visitType, CareType careType, string notes)
    {
        try
        {
            var appointment = new Appointment(firstName, lastName, dateTime)
            {
                VisitType = visitType,
                CareType = careType,
                Notes = notes
            };

            return Add(appointment);
        }
        catch (ArgumentException)
        {
            return false;
        }
    }

    // Returns the appointment at the chosen index.
    public Appointment? GetAt(int index)
    {
        if (!IsValidIndex(index))
        {
            return null;
        }

        return appointments[index];
    }

    // Replaces the appointment at the chosen index.
    public bool ChangeAt(int index, Appointment newAppointment)
    {
        if (newAppointment is null || !IsValidIndex(index))
        {
            return false;
        }

        appointments[index] = newAppointment;
        return true;
    }

    // Removes one appointment and shifts the rest left.
    public bool RemoveAt(int index)
    {
        if (!IsValidIndex(index))
        {
            return false;
        }

        // Shift every item after the removed position one step left.
        // This keeps the stored part of the array compact (no gaps).
        for (int i = index; i < numOfElements - 1; i++)
        {
            appointments[i] = appointments[i + 1];
        }

        // Clear the last used slot and reduce the element count.
        appointments[numOfElements - 1] = null;
        numOfElements--;
        return true;
    }

    // Returns a simple text line for each stored appointment.
    public string[] GetInfoStrings()
    {
        string[] infoStrings = new string[numOfElements];

        for (int i = 0; i < numOfElements; i++)
        {
            Appointment? appointment = appointments[i];
            if (appointment is not null)
            {
                infoStrings[i] = appointment.ToString();
            }
            else
            {
                infoStrings[i] = string.Empty;
            }
        }

        return infoStrings;
    }

    // Finds appointments by a single date or by a whole month.
    public string[,] FilterByDateOrMonth(DateTime date, bool useMonth)
    {
        // First pass: count matches to create a fixed-size result array.
        int matchCount = 0;

        for (int i = 0; i < numOfElements; i++)
        {
            Appointment? appointment = appointments[i];
            if (appointment is not null && MatchesDateOrMonth(appointment, date, useMonth))
            {
                matchCount++;
            }
        }

        string[,] result = new string[matchCount, 4];
        int row = 0;

        // Second pass: write matching appointments to the result table.
        for (int i = 0; i < numOfElements; i++)
        {
            Appointment? current = appointments[i];
            if (current is null)
            {
                continue;
            }

            if (!MatchesDateOrMonth(current, date, useMonth))
            {
                continue;
            }

            FillResultRow(result, row, current);
            row++;
        }

        return result;
    }

    // Finds appointments by care provider type.
    public string[,] FilterByCareType(CareType careType)
    {
        // First pass: count matches to create a fixed-size result array.
        int matchCount = 0;

        for (int i = 0; i < numOfElements; i++)
        {
            Appointment? appointment = appointments[i];
            if (appointment is not null && appointment.CareType == careType)
            {
                matchCount++;
            }
        }

        string[,] result = new string[matchCount, 4];
        int row = 0;

        // Second pass: write matching appointments to the result table.
        for (int i = 0; i < numOfElements; i++)
        {
            Appointment? current = appointments[i];
            if (current is null)
            {
                continue;
            }

            if (current.CareType != careType)
            {
                continue;
            }

            FillResultRow(result, row, current);
            row++;
        }

        return result;
    }

    // Checks whether an index is inside the stored range.
    private bool IsValidIndex(int index)
    {
        return index >= 0 && index < numOfElements;
    }

    // Checks if an appointment matches a date or a month.
    private static bool MatchesDateOrMonth(Appointment appointment, DateTime date, bool useMonth)
    {
        if (useMonth)
        {
            return appointment.AppointmentDateTime.Year == date.Year &&
                   appointment.AppointmentDateTime.Month == date.Month;
        }

        return appointment.AppointmentDateTime.Date == date.Date;
    }

    // Writes one appointment into the two-dimensional result table.
    private static void FillResultRow(string[,] result, int row, Appointment appointment)
    {
        result[row, 0] = appointment.CareType.ToString();
        result[row, 1] = appointment.AppointmentDateTime.ToString("yyyy-MM-dd HH:mm");
        result[row, 2] = $"{appointment.FirstName} {appointment.LastName}";
        result[row, 3] = appointment.VisitType.ToString();
    }
}
