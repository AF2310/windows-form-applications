namespace Assignment4;

// Type of visit chosen for one appointment.
public enum VisitType
{
    FirstVisit,
    FollowUp,
    Emergency,
    RoutineCheck,
    Consultation,
    Vaccination
}

// Type of care provider chosen for one appointment.
public enum CareType
{
    Doctor,
    Nurse,
    Physiotherapist,
    Receptionist,
    Specialist,
    Consultant
}