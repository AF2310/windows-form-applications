using System.Drawing;
using System.Windows.Forms;

namespace Assignment4;

// Main window for the time-booking application.
public class MainForm : Form
{
    // One fixed manager object for all appointments.
    private readonly BookingManager bookingManager = new(20);

    // Input controls for appointment details.
    private readonly TextBox txtFirstName = new();
    private readonly TextBox txtLastName = new();
    private readonly DateTimePicker dtpAppointment = new();
    private readonly ComboBox cmbVisitType = new();
    private readonly ComboBox cmbCareType = new();
    private readonly TextBox txtNotes = new();

    // Controls for filtering.
    private readonly DateTimePicker dtpFilterDate = new();
    private readonly RadioButton rbFilterExactDate = new();
    private readonly RadioButton rbFilterMonth = new();
    private readonly ComboBox cmbFilterCareType = new();

    // Output controls.
    private readonly ListBox lstAppointments = new();
    private readonly Label lblCount = new();

    // Keeps the visible list aligned with the real array indexes.
    private int[] displayedIndices = Array.Empty<int>();

    // Builds the form.
    public MainForm()
    {
        Text = "Assignment 4 - Time Booking Application";
        Width = 1100;
        Height = 850;
        StartPosition = FormStartPosition.CenterScreen;

        BuildUi();
        InitializeGUI();
        UpdateGUI();
    }

    // Builds all controls and puts them on the form.
    private void BuildUi()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            ColumnCount = 1,
            RowCount = 4,
            Padding = new Padding(12)
        };

        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var title = new Label
        {
            AutoSize = true,
            Text = "Assignment 4 - Time Booking Application",
            Font = new Font(Font, FontStyle.Bold),
            Margin = new Padding(3, 3, 3, 12)
        };

        root.Controls.Add(title, 0, 0);
        root.Controls.Add(BuildAppointmentGroup(), 0, 1);
        root.Controls.Add(BuildFilterGroup(), 0, 2);
        root.Controls.Add(BuildListGroup(), 0, 3);

        Controls.Add(root);
    }

    // Builds the appointment input section.
    private Control BuildAppointmentGroup()
    {
        var group = new GroupBox
        {
            Text = "Add, change, and remove appointments",
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(10)
        };

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            AutoSize = true
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

        AddRow(layout, 0, "First name", txtFirstName, "Last name", txtLastName);
        AddRow(layout, 1, "Appointment date/time", dtpAppointment, "Visit type", cmbVisitType);
        AddRow(layout, 2, "Care type", cmbCareType, "Notes", txtNotes);

        var buttonPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            Margin = new Padding(3, 8, 3, 8)
        };

        var btnAdd = new Button { Text = "Add", AutoSize = true, Width = 100 };
        var btnChange = new Button { Text = "Change", AutoSize = true, Width = 100 };
        var btnRemove = new Button { Text = "Remove", AutoSize = true, Width = 100 };

        btnAdd.Click += (_, _) => AddAppointment();
        btnChange.Click += (_, _) => ChangeAppointment();
        btnRemove.Click += (_, _) => RemoveAppointment();

        buttonPanel.Controls.Add(btnAdd);
        buttonPanel.Controls.Add(btnChange);
        buttonPanel.Controls.Add(btnRemove);

        layout.Controls.Add(buttonPanel, 0, 3);
        layout.SetColumnSpan(buttonPanel, 4);

        group.Controls.Add(layout);
        return group;
    }

    // Builds the filter section.
    private Control BuildFilterGroup()
    {
        var group = new GroupBox
        {
            Text = "Filtering",
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(10)
        };

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            AutoSize = true
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

        var filterModePanel = new FlowLayoutPanel
        {
            AutoSize = true,
            Dock = DockStyle.Fill,
            Margin = new Padding(3, 3, 3, 3)
        };

        rbFilterExactDate.Text = "Exact date";
        rbFilterMonth.Text = "Same month";
        filterModePanel.Controls.Add(rbFilterExactDate);
        filterModePanel.Controls.Add(rbFilterMonth);

        AddRow(layout, 0, "Filter date", dtpFilterDate, "Mode", filterModePanel);
        AddRow(layout, 1, "Care type", cmbFilterCareType, "", new Label());

        var buttonPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            Margin = new Padding(3, 8, 3, 8)
        };

        var btnFilterDate = new Button { Text = "Filter by date/month", AutoSize = true, Width = 160 };
        var btnFilterCareType = new Button { Text = "Filter by care type", AutoSize = true, Width = 160 };
        var btnShowAll = new Button { Text = "Show all", AutoSize = true, Width = 100 };

        btnFilterDate.Click += (_, _) => FilterByDateOrMonth();
        btnFilterCareType.Click += (_, _) => FilterByCareType();
        btnShowAll.Click += (_, _) => UpdateGUI();

        buttonPanel.Controls.Add(btnFilterDate);
        buttonPanel.Controls.Add(btnFilterCareType);
        buttonPanel.Controls.Add(btnShowAll);

        layout.Controls.Add(buttonPanel, 0, 2);
        layout.SetColumnSpan(buttonPanel, 4);

        group.Controls.Add(layout);
        return group;
    }

    // Builds the list box section.
    private Control BuildListGroup()
    {
        var group = new GroupBox
        {
            Text = "Stored appointments",
            Dock = DockStyle.Fill,
            AutoSize = true,
            Padding = new Padding(10)
        };

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 2,
            AutoSize = true
        };

        layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        lstAppointments.Dock = DockStyle.Fill;
        lstAppointments.Height = 280;
        lstAppointments.HorizontalScrollbar = true;
        lstAppointments.SelectedIndexChanged += (_, _) => LoadSelectedAppointment();

        lblCount.AutoSize = true;

        layout.Controls.Add(lstAppointments, 0, 0);
        layout.Controls.Add(lblCount, 0, 1);

        group.Controls.Add(layout);
        return group;
    }

    // Adds a pair of labels and controls to one row.
    private static void AddRow(TableLayoutPanel panel, int row, string leftLabel, Control leftControl, string rightLabel, Control rightControl)
    {
        panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        panel.Controls.Add(new Label { Text = leftLabel, AutoSize = true, Anchor = AnchorStyles.Left }, 0, row);
        leftControl.Dock = DockStyle.Fill;
        panel.Controls.Add(leftControl, 1, row);

        panel.Controls.Add(new Label { Text = rightLabel, AutoSize = true, Anchor = AnchorStyles.Left }, 2, row);
        rightControl.Dock = DockStyle.Fill;
        panel.Controls.Add(rightControl, 3, row);
    }

    // Sets default values and simple control settings.
    private void InitializeGUI()
    {
        cmbVisitType.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbVisitType.DataSource = Enum.GetValues(typeof(VisitType));
        cmbVisitType.SelectedItem = VisitType.RoutineCheck;

        cmbCareType.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbCareType.DataSource = Enum.GetValues(typeof(CareType));
        cmbCareType.SelectedItem = CareType.Doctor;

        cmbFilterCareType.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbFilterCareType.Items.Clear();
        cmbFilterCareType.Items.Add("All");
        foreach (CareType careType in Enum.GetValues(typeof(CareType)))
        {
            cmbFilterCareType.Items.Add(careType);
        }
        cmbFilterCareType.SelectedIndex = 0;

        dtpAppointment.Format = DateTimePickerFormat.Custom;
        dtpAppointment.CustomFormat = "yyyy-MM-dd HH:mm";
        dtpAppointment.ShowUpDown = true;

        dtpFilterDate.Format = DateTimePickerFormat.Custom;
        dtpFilterDate.CustomFormat = "yyyy-MM-dd";
        dtpFilterDate.ShowUpDown = false;

        txtNotes.Multiline = true;
        txtNotes.ScrollBars = ScrollBars.Vertical;
        txtNotes.Height = 60;

        rbFilterExactDate.Checked = true;

        ClearInputFields();
    }

    // Adds a new appointment to the fixed array.
    private void AddAppointment()
    {
        if (!TryCreateAppointmentFromInputs(out Appointment? appointment))
        {
            return;
        }

        if (!bookingManager.Add(appointment))
        {
            ShowError("The booking list is full.");
            return;
        }

        UpdateGUI();
        ClearInputFields();
    }

    // Changes the selected appointment.
    private void ChangeAppointment()
    {
        int selectedIndex = GetSelectedStoredIndex();
        if (selectedIndex < 0)
        {
            ShowError("Please select an appointment first.");
            return;
        }

        if (!TryCreateAppointmentFromInputs(out Appointment? appointment))
        {
            return;
        }

        if (!bookingManager.ChangeAt(selectedIndex, appointment))
        {
            ShowError("The selected appointment could not be changed.");
            return;
        }

        UpdateGUI();
        ClearInputFields();
    }

    // Removes the selected appointment.
    private void RemoveAppointment()
    {
        int selectedIndex = GetSelectedStoredIndex();
        if (selectedIndex < 0)
        {
            ShowError("Please select an appointment first.");
            return;
        }

        if (!bookingManager.RemoveAt(selectedIndex))
        {
            ShowError("The selected appointment could not be removed.");
            return;
        }

        UpdateGUI();
        ClearInputFields();
    }

    // Filters appointments by date or by month.
    private void FilterByDateOrMonth()
    {
        if (bookingManager.Count == 0)
        {
            ShowInfo("There are no appointments to filter.");
            return;
        }

        bool useMonth = rbFilterMonth.Checked;
        string[,] table = bookingManager.FilterByDateOrMonth(dtpFilterDate.Value, useMonth);
        int[] indices = BuildFilteredIndicesByDateOrMonth(dtpFilterDate.Value, useMonth);

        if (table.GetLength(0) == 0)
        {
            ShowInfo("No appointments matched the selected date.");
            lstAppointments.Items.Clear();
            displayedIndices = Array.Empty<int>();
            return;
        }

        ShowFilteredTable(table, indices);
    }

    // Filters appointments by care provider type.
    private void FilterByCareType()
    {
        if (bookingManager.Count == 0)
        {
            ShowInfo("There are no appointments to filter.");
            return;
        }

        // The filter combo contains "All" as a string plus enum values.
        object? selectedFilter = cmbFilterCareType.SelectedItem;

        // If user selected "All", show the full list again.
        if (selectedFilter is string)
        {
            UpdateGUI();
            return;
        }

        if (selectedFilter is null)
        {
            ShowError("Please choose a care type to filter by.");
            return;
        }

        CareType careType = (CareType)selectedFilter;

        string[,] table = bookingManager.FilterByCareType(careType);
        int[] indices = BuildFilteredIndicesByCareType(careType);

        if (table.GetLength(0) == 0)
        {
            ShowInfo("No appointments matched the selected care type.");
            lstAppointments.Items.Clear();
            displayedIndices = Array.Empty<int>();
            return;
        }

        ShowFilteredTable(table, indices);
    }

    // Rebuilds the full list from the manager.
    private void UpdateGUI()
    {
        string[] infoStrings = bookingManager.GetInfoStrings();

        displayedIndices = new int[infoStrings.Length];
        lstAppointments.BeginUpdate();
        lstAppointments.Items.Clear();

        for (int i = 0; i < infoStrings.Length; i++)
        {
            lstAppointments.Items.Add(infoStrings[i]);
            displayedIndices[i] = i;
        }

        lstAppointments.EndUpdate();
        lblCount.Text = $"Stored appointments: {bookingManager.Count} / {bookingManager.Capacity}";
    }

    // Shows a filtered two-dimensional result in the list box.
    private void ShowFilteredTable(string[,] table, int[] indices)
    {
        displayedIndices = indices;

        lstAppointments.BeginUpdate();
        lstAppointments.Items.Clear();

        for (int row = 0; row < table.GetLength(0); row++)
        {
            string line = $"{table[row, 0]} | {table[row, 1]} | {table[row, 2]} | {table[row, 3]}";
            lstAppointments.Items.Add(line);
        }

        lstAppointments.EndUpdate();
    }

    // Returns the real array index for the selected row.
    private int GetSelectedStoredIndex()
    {
        int visibleIndex = lstAppointments.SelectedIndex;
        if (visibleIndex < 0 || visibleIndex >= displayedIndices.Length)
        {
            return -1;
        }

        // Convert the visible row index to the real array index.
        // This is needed because filtered lists can hide some rows.
        return displayedIndices[visibleIndex];
    }

    // Loads the selected appointment into the input controls.
    private void LoadSelectedAppointment()
    {
        int storedIndex = GetSelectedStoredIndex();
        if (storedIndex < 0)
        {
            return;
        }

        Appointment? appointment = bookingManager.GetAt(storedIndex);
        if (appointment is null)
        {
            return;
        }

        txtFirstName.Text = appointment.FirstName;
        txtLastName.Text = appointment.LastName;
        dtpAppointment.Value = appointment.AppointmentDateTime;
        cmbVisitType.SelectedItem = appointment.VisitType;
        cmbCareType.SelectedItem = appointment.CareType;
        txtNotes.Text = appointment.Notes;
    }

    // Reads the text boxes and creates one Appointment object.
    private bool TryCreateAppointmentFromInputs(out Appointment appointment)
    {
        // Give the out parameter a default value for compiler safety.
        appointment = null!;

        try
        {
            object? selectedVisit = cmbVisitType.SelectedItem;
            object? selectedCare = cmbCareType.SelectedItem;

            if (selectedVisit is null || selectedCare is null)
            {
                ShowError("Please choose both Visit type and Care type.");
                return false;
            }

            VisitType visitType = (VisitType)selectedVisit;
            CareType careType = (CareType)selectedCare;

            // Build the appointment in small clear steps.
            appointment = new Appointment(txtFirstName.Text, txtLastName.Text, dtpAppointment.Value);
            appointment.VisitType = visitType;
            appointment.CareType = careType;
            appointment.Notes = txtNotes.Text;

            return true;
        }
        catch (ArgumentException ex)
        {
            ShowError(ex.Message);
            return false;
        }
    }

    // Builds the index array for a date or month filter.
    private int[] BuildFilteredIndicesByDateOrMonth(DateTime date, bool useMonth)
    {
        // First pass: count matches so we can create an array with exact size.
        int matchCount = 0;

        for (int i = 0; i < bookingManager.Count; i++)
        {
            Appointment? appointment = bookingManager.GetAt(i);
            if (appointment is not null && MatchesDateOrMonth(appointment, date, useMonth))
            {
                matchCount++;
            }
        }

        int[] indices = new int[matchCount];
        int position = 0;

        // Second pass: store the indexes of matching appointments.
        for (int i = 0; i < bookingManager.Count; i++)
        {
            Appointment? appointment = bookingManager.GetAt(i);
            if (appointment is not null && MatchesDateOrMonth(appointment, date, useMonth))
            {
                indices[position] = i;
                position++;
            }
        }

        return indices;
    }

    // Builds the index array for a care type filter.
    private int[] BuildFilteredIndicesByCareType(CareType careType)
    {
        // First pass: count matches so we can create an array with exact size.
        int matchCount = 0;

        for (int i = 0; i < bookingManager.Count; i++)
        {
            Appointment? appointment = bookingManager.GetAt(i);
            if (appointment is not null && appointment.CareType == careType)
            {
                matchCount++;
            }
        }

        int[] indices = new int[matchCount];
        int position = 0;

        // Second pass: store the indexes of matching appointments.
        for (int i = 0; i < bookingManager.Count; i++)
        {
            Appointment? appointment = bookingManager.GetAt(i);
            if (appointment is not null && appointment.CareType == careType)
            {
                indices[position] = i;
                position++;
            }
        }

        return indices;
    }

    // Checks whether an appointment matches the chosen date or month.
    private static bool MatchesDateOrMonth(Appointment appointment, DateTime date, bool useMonth)
    {
        if (useMonth)
        {
            return appointment.AppointmentDateTime.Year == date.Year &&
                   appointment.AppointmentDateTime.Month == date.Month;
        }

        return appointment.AppointmentDateTime.Date == date.Date;
    }

    // Clears all input fields so the user can start fresh.
    private void ClearInputFields()
    {
        txtFirstName.Clear();
        txtLastName.Clear();
        txtNotes.Clear();
        dtpAppointment.Value = DateTime.Now;
        cmbVisitType.SelectedItem = VisitType.RoutineCheck;
        cmbCareType.SelectedItem = CareType.Doctor;
        lstAppointments.ClearSelected();
    }

    // Shows one warning message.
    private static void ShowError(string message)
    {
        MessageBox.Show(message, "Input error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }

    // Shows one simple information message.
    private static void ShowInfo(string message)
    {
        MessageBox.Show(message, "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}
