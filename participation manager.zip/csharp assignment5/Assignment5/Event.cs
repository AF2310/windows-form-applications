using System;

namespace Assignment5App
{
    // Model for an event with participants and pricing
    public class Event
    {
        private readonly ParticipantManager _participantManager = new ParticipantManager();
        private string _title = string.Empty;
        private double _costPerPerson = 0.0;
        private double _feePerPerson = 0.0;
        private DateTime? _eventDateTime;

        // Access the participant manager
        public ParticipantManager ParticipantManager => _participantManager;

        // Event title
        public string Title
        {
            get => _title;
            set => _title = value ?? string.Empty;
        }

        // Cost per person
        public double CostPerPerson
        {
            get => _costPerPerson;
            set => _costPerPerson = value;
        }

        // Fee per person
        public double FeePerPerson
        {
            get => _feePerPerson;
            set => _feePerPerson = value;
        }

        // Event date and time (optional)
        public DateTime? EventDateTime
        {
            get => _eventDateTime;
            set => _eventDateTime = value;
        }

        // Calculate total cost for all participants
        public double TotalCost() => CostPerPerson * _participantManager.Count;

        // Calculate total fees from all participants
        public double TotalFees() => FeePerPerson * _participantManager.Count;

        // Return fees minus cost
        public double Difference() => TotalFees() - TotalCost();
    }
}
