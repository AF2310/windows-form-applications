using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Assignment5App
{
    // Manage a list of participants
    public class ParticipantManager
    {
        private readonly List<Participant> _participants = new List<Participant>();

        // Add a participant
        public void AddParticipant(Participant participant)
        {
            if (participant == null)
            {
                throw new ArgumentNullException(nameof(participant));
            }

            _participants.Add(participant);
        }

        // Get participant by index
        public Participant GetParticipant(int index)
        {
            if (index < 0 || index >= _participants.Count)
            {
                throw new ArgumentOutOfRangeException(nameof(index));
            }

            return _participants[index];
        }

        // Update participant at index
        public void UpdateParticipant(int index, Participant participant)
        {
            if (participant == null)
            {
                throw new ArgumentNullException(nameof(participant));
            }

            if (index < 0 || index >= _participants.Count)
            {
                throw new ArgumentOutOfRangeException(nameof(index));
            }

            _participants[index] = participant;
        }

        // Remove participant at index
        public void DeleteParticipant(int index)
        {
            if (index < 0 || index >= _participants.Count)
            {
                throw new ArgumentOutOfRangeException(nameof(index));
            }

            _participants.RemoveAt(index);
        }

        // Current participant count
        public int Count => _participants.Count;

        // Get display strings for all participants
        public string[] GetParticipantStrings()
        {
            return _participants.Select(p => p.ToString()).ToArray();
        }

        // Clear all participants
        public void Reset()
        {
            _participants.Clear();
        }

        // Save participants to a text file
        public void SaveToFile(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                throw new ArgumentNullException(nameof(path));
            }

            using var writer = new StreamWriter(path, false);

            foreach (var p in _participants)
            {
                var first = p.FirstName.Replace('|', ' ');
                var last = p.LastName.Replace('|', ' ');
                var street = p.Address.Street.Replace('|', ' ');
                var city = p.Address.City.Replace('|', ' ');
                var zip = p.Address.ZipCode.Replace('|', ' ');
                var country = p.Address.Country.ToString();
                writer.WriteLine($"{first}|{last}|{street}|{city}|{zip}|{country}");
            }
        }

        // Load participants from a text file
        public void LoadFromFile(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
            {
                throw new ArgumentNullException(nameof(path));
            }

            if (!File.Exists(path))
            {
                throw new FileNotFoundException("File not found", path);
            }

            _participants.Clear();

            foreach (var line in File.ReadLines(path))
            {
                if (string.IsNullOrWhiteSpace(line))
                {
                    continue;
                }

                var parts = line.Split('|');
                if (parts.Length != 6)
                {
                    continue;
                }

                var first = parts[0];
                var last = parts[1];
                var street = parts[2];
                var city = parts[3];
                var zip = parts[4];
                var countryStr = parts[5];

                Countries country;
                if (!Enum.TryParse<Countries>(countryStr, out country))
                {
                    country = Countries.Afghanistan;
                }

                _participants.Add(new Participant(first, last, new Address(street, city, zip, country)));
            }
        }
    }
}
