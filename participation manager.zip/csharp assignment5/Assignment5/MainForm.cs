using System;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace Assignment5App
{
    // Main application window
    public class MainForm : Form
    {
        // Menu controls
        private MenuStrip _menu = null!;
        private ToolStripMenuItem _fileMenu = null!;
        private ToolStripMenuItem _newMenuItem = null!;
        private ToolStripMenuItem _openMenuItem = null!;
        private ToolStripMenuItem _saveMenuItem = null!;
        private ToolStripMenuItem _saveAsMenuItem = null!;
        private ToolStripMenuItem _exitMenuItem = null!;

        // Event input controls
        private GroupBox _eventGroup = null!;
        private TextBox _titleBox = null!;
        private NumericUpDown _costBox = null!;
        private NumericUpDown _feeBox = null!;
        private DateTimePicker _datePicker = null!;
        private DateTimePicker _timePicker = null!;
        private Button _createEventButton = null!;

        // Participant input controls
        private GroupBox _participantGroup = null!;
        private TextBox _firstBox = null!;
        private TextBox _lastBox = null!;
        private TextBox _streetBox = null!;
        private TextBox _cityBox = null!;
        private TextBox _zipBox = null!;
        private ComboBox _countryBox = null!;
        private Button _addButton = null!;
        private Button _modifyButton = null!;
        private Button _deleteButton = null!;
        private ListBox _listBox = null!;

        // Domain objects
        private Event _event = new Event();
        private string? _currentFilePath;

        // Construct and initialize the main window
        public MainForm()
        {
            Text = "EventManager - Assignment 5";
            Width = 900;
            Height = 600;

            InitializeComponents();
            InitializeLayout();

            UpdateParticipantList();
            SetInitialState();
        }

        // Initialize UI controls
        private void InitializeComponents()
        {
            _menu = new MenuStrip();

            _fileMenu = new ToolStripMenuItem("File");

            _newMenuItem = new ToolStripMenuItem("New", null, NewMenu_Click);
            _openMenuItem = new ToolStripMenuItem("Open", null, OpenMenu_Click);
            _saveMenuItem = new ToolStripMenuItem("Save", null, SaveMenu_Click);
            _saveAsMenuItem = new ToolStripMenuItem("Save As", null, SaveAsMenu_Click);
            _exitMenuItem = new ToolStripMenuItem("Exit", null, ExitMenu_Click);

            _fileMenu.DropDownItems.Add(_newMenuItem);
            _fileMenu.DropDownItems.Add(_openMenuItem);
            _fileMenu.DropDownItems.Add(_saveMenuItem);
            _fileMenu.DropDownItems.Add(_saveAsMenuItem);
            _fileMenu.DropDownItems.Add(new ToolStripSeparator());
            _fileMenu.DropDownItems.Add(_exitMenuItem);

            _menu.Items.Add(_fileMenu);
            MainMenuStrip = _menu;
            Controls.Add(_menu);

            _eventGroup = new GroupBox();
            _eventGroup.Text = "Event";
            _eventGroup.Left = 10;
            _eventGroup.Top = 30;
            _eventGroup.Width = 860;
            _eventGroup.Height = 120;

            _titleBox = new TextBox();
            _titleBox.Left = 100;
            _titleBox.Top = 20;
            _titleBox.Width = 300;

            _costBox = new NumericUpDown();
            _costBox.Left = 520;
            _costBox.Top = 20;
            _costBox.Width = 80;
            _costBox.DecimalPlaces = 2;
            _costBox.Maximum = 1_000_000;

            _feeBox = new NumericUpDown();
            _feeBox.Left = 700;
            _feeBox.Top = 20;
            _feeBox.Width = 80;
            _feeBox.DecimalPlaces = 2;
            _feeBox.Maximum = 1_000_000;

            _datePicker = new DateTimePicker();
            _datePicker.Left = 100;
            _datePicker.Top = 55;
            _datePicker.Width = 200;
            _datePicker.Format = DateTimePickerFormat.Short;

            _timePicker = new DateTimePicker();
            _timePicker.Left = 320;
            _timePicker.Top = 55;
            _timePicker.Width = 120;
            _timePicker.Format = DateTimePickerFormat.Time;
            _timePicker.ShowUpDown = true;

            _createEventButton = new Button();
            _createEventButton.Text = "Create Event";
            _createEventButton.Left = 520;
            _createEventButton.Top = 55;
            _createEventButton.Width = 120;
            _createEventButton.Click += CreateEventButton_Click;

            var titleLabel = new Label();
            titleLabel.Text = "Title:";
            titleLabel.Left = 10;
            titleLabel.Top = 22;

            var costLabel = new Label();
            costLabel.Text = "Cost/Person:";
            costLabel.Left = 430;
            costLabel.Top = 22;

            var feeLabel = new Label();
            feeLabel.Text = "Fee/Person:";
            feeLabel.Left = 620;
            feeLabel.Top = 22;

            var dateLabel = new Label();
            dateLabel.Text = "Date:";
            dateLabel.Left = 10;
            dateLabel.Top = 58;

            var timeLabel = new Label();
            timeLabel.Text = "Time:";
            timeLabel.Left = 280;
            timeLabel.Top = 58;

            _eventGroup.Controls.Add(titleLabel);
            _eventGroup.Controls.Add(_titleBox);
            _eventGroup.Controls.Add(costLabel);
            _eventGroup.Controls.Add(_costBox);
            _eventGroup.Controls.Add(feeLabel);
            _eventGroup.Controls.Add(_feeBox);
            _eventGroup.Controls.Add(dateLabel);
            _eventGroup.Controls.Add(_datePicker);
            _eventGroup.Controls.Add(timeLabel);
            _eventGroup.Controls.Add(_timePicker);
            _eventGroup.Controls.Add(_createEventButton);

            Controls.Add(_eventGroup);

            _participantGroup = new GroupBox();
            _participantGroup.Text = "Participants";
            _participantGroup.Left = 10;
            _participantGroup.Top = 160;
            _participantGroup.Width = 860;
            _participantGroup.Height = 380;

            _firstBox = new TextBox();
            _firstBox.Left = 100;
            _firstBox.Top = 20;
            _firstBox.Width = 200;

            _lastBox = new TextBox();
            _lastBox.Left = 420;
            _lastBox.Top = 20;
            _lastBox.Width = 200;

            _streetBox = new TextBox();
            _streetBox.Left = 100;
            _streetBox.Top = 55;
            _streetBox.Width = 200;

            _cityBox = new TextBox();
            _cityBox.Left = 420;
            _cityBox.Top = 55;
            _cityBox.Width = 200;

            _zipBox = new TextBox();
            _zipBox.Left = 100;
            _zipBox.Top = 90;
            _zipBox.Width = 200;

            _countryBox = new ComboBox();
            _countryBox.Left = 420;
            _countryBox.Top = 90;
            _countryBox.Width = 200;
            _countryBox.DropDownStyle = ComboBoxStyle.DropDownList;

            foreach (var c in Enum.GetValues(typeof(Countries)).Cast<Countries>())
            {
                var display = c.ToString().Replace('_', ' ');
                _countryBox.Items.Add(display);
            }

            if (_countryBox.Items.Count > 0)
            {
                _countryBox.SelectedIndex = 0;
            }

            _addButton = new Button();
            _addButton.Text = "Add";
            _addButton.Left = 650;
            _addButton.Top = 20;
            _addButton.Width = 80;
            _addButton.Click += AddButton_Click;

            _modifyButton = new Button();
            _modifyButton.Text = "Modify";
            _modifyButton.Left = 650;
            _modifyButton.Top = 55;
            _modifyButton.Width = 80;
            _modifyButton.Click += ModifyButton_Click;

            _deleteButton = new Button();
            _deleteButton.Text = "Delete";
            _deleteButton.Left = 650;
            _deleteButton.Top = 90;
            _deleteButton.Width = 80;
            _deleteButton.Click += DeleteButton_Click;

            _listBox = new ListBox();
            _listBox.Left = 10;
            _listBox.Top = 130;
            _listBox.Width = 820;
            _listBox.Height = 230;
            _listBox.SelectedIndexChanged += ListBox_SelectedIndexChanged;

            var firstLabel = new Label();
            firstLabel.Text = "First name:";
            firstLabel.Left = 10;
            firstLabel.Top = 22;

            var lastLabel = new Label();
            lastLabel.Text = "Last name:";
            lastLabel.Left = 330;
            lastLabel.Top = 22;

            var streetLabel = new Label();
            streetLabel.Text = "Street:";
            streetLabel.Left = 10;
            streetLabel.Top = 58;

            var cityLabel = new Label();
            cityLabel.Text = "City:";
            cityLabel.Left = 330;
            cityLabel.Top = 58;

            var zipLabel = new Label();
            zipLabel.Text = "Zip:";
            zipLabel.Left = 10;
            zipLabel.Top = 93;

            var countryLabel = new Label();
            countryLabel.Text = "Country:";
            countryLabel.Left = 330;
            countryLabel.Top = 93;

            _participantGroup.Controls.Add(firstLabel);
            _participantGroup.Controls.Add(_firstBox);
            _participantGroup.Controls.Add(lastLabel);
            _participantGroup.Controls.Add(_lastBox);
            _participantGroup.Controls.Add(streetLabel);
            _participantGroup.Controls.Add(_streetBox);
            _participantGroup.Controls.Add(cityLabel);
            _participantGroup.Controls.Add(_cityBox);
            _participantGroup.Controls.Add(zipLabel);
            _participantGroup.Controls.Add(_zipBox);
            _participantGroup.Controls.Add(countryLabel);
            _participantGroup.Controls.Add(_countryBox);
            _participantGroup.Controls.Add(_addButton);
            _participantGroup.Controls.Add(_modifyButton);
            _participantGroup.Controls.Add(_deleteButton);
            _participantGroup.Controls.Add(_listBox);
            Controls.Add(_participantGroup);
        }

        // Configure layout (no-op)
        private void InitializeLayout()
        {
            // Layout is already defined using coordinates above.
        }

        // Set initial control state before an event is created
        private void SetInitialState()
        {
            _participantGroup.Enabled = false;
            _currentFilePath = null;
        }

        // Handle Create Event button click
        private void CreateEventButton_Click(object? sender, EventArgs e)
        {
            var title = _titleBox.Text?.Trim();

            if (string.IsNullOrWhiteSpace(title))
            {
                MessageBox.Show("Title is mandatory.", "Validation", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _event.Title = title;
            _event.CostPerPerson = (double)_costBox.Value;
            _event.FeePerPerson = (double)_feeBox.Value;

            var date = _datePicker.Value.Date;
            var time = _timePicker.Value.TimeOfDay;
            _event.EventDateTime = date + time;

            _participantGroup.Enabled = true;
            UpdateStatus();
        }

        // Add a participant from input fields
        private void AddButton_Click(object? sender, EventArgs e)
        {
            var participant = ReadParticipantFromInputs();
            _event.ParticipantManager.AddParticipant(participant);
            UpdateParticipantList();
            UpdateStatus();
        }

        // Read participant values from the input fields
        private Participant ReadParticipantFromInputs()
        {
            var countryIndex = _countryBox.SelectedIndex;
            var countryNames = Enum.GetNames(typeof(Countries));
            Countries country = Countries.Afghanistan;

            if (countryIndex >= 0 && countryIndex < countryNames.Length)
            {
                var enumName = countryNames[countryIndex];
                if (!Enum.TryParse(enumName, out country))
                {
                    country = Countries.Afghanistan;
                }
            }

            var addr = new Address(_streetBox.Text, _cityBox.Text, _zipBox.Text, country);
            var participant = new Participant(_firstBox.Text, _lastBox.Text, addr);
            return participant;
        }

        // Modify the selected participant using the input fields
        private void ModifyButton_Click(object? sender, EventArgs e)
        {
            var idx = _listBox.SelectedIndex;
            if (idx < 0)
            {
                MessageBox.Show("Select a participant first.");
                return;
            }

            var p = ReadParticipantFromInputs();
            _event.ParticipantManager.UpdateParticipant(idx, p);
            UpdateParticipantList();
            _listBox.SelectedIndex = idx;
            UpdateStatus();
        }

        // Delete the selected participant
        private void DeleteButton_Click(object? sender, EventArgs e)
        {
            var idx = _listBox.SelectedIndex;
            if (idx < 0)
            {
                MessageBox.Show("Select a participant first.");
                return;
            }

            _event.ParticipantManager.DeleteParticipant(idx);
            UpdateParticipantList();
            UpdateStatus();
        }

        // Refresh the participant list display
        private void UpdateParticipantList()
        {
            _listBox.Items.Clear();
            _listBox.Items.AddRange(_event.ParticipantManager.GetParticipantStrings());
        }

        // Populate input fields from the selected participant
        private void ListBox_SelectedIndexChanged(object? sender, EventArgs e)
        {
            var idx = _listBox.SelectedIndex;
            if (idx < 0)
            {
                return;
            }

            var p = _event.ParticipantManager.GetParticipant(idx);
            _firstBox.Text = p.FirstName;
            _lastBox.Text = p.LastName;
            _streetBox.Text = p.Address.Street;
            _cityBox.Text = p.Address.City;
            _zipBox.Text = p.Address.ZipCode;

            var enumName = p.Address.Country.ToString();
            var display = enumName.Replace('_', ' ');
            var idx2 = _countryBox.Items.IndexOf(display);
            if (idx2 >= 0)
            {
                _countryBox.SelectedIndex = idx2;
            }
        }

        // Update window title with event status
        private void UpdateStatus()
        {
            Text = $"EventManager - {_event.Title} | Participants: {_event.ParticipantManager.Count} | Income: {_event.TotalFees():0.00} | Cost: {_event.TotalCost():0.00} | Diff: {_event.Difference():0.00}";
        }

        // Reset application to an empty event
        private void NewMenu_Click(object? sender, EventArgs e)
        {
            if (!ConfirmDiscardChanges())
            {
                return;
            }

            _event = new Event();
            _titleBox.Text = string.Empty;
            _costBox.Value = 0;
            _feeBox.Value = 0;
            _datePicker.Value = DateTime.Now;
            _timePicker.Value = DateTime.Now;
            _participantGroup.Enabled = false;
            _currentFilePath = null;
            UpdateParticipantList();
            UpdateStatus();
        }

        // Ask user to confirm discarding changes
        private bool ConfirmDiscardChanges()
        {
            var r = MessageBox.Show("Reset application to initial state? Unsaved changes will be lost.", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            return r == DialogResult.OK;
        }

        // Open a participant file and load it
        private void OpenMenu_Click(object? sender, EventArgs e)
        {
            if (!ConfirmDiscardChanges())
            {
                return;
            }

            using var ofd = new OpenFileDialog();
            ofd.Filter = "Text files|*.txt|All files|*.*";
            if (ofd.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            try
            {
                _event.ParticipantManager.LoadFromFile(ofd.FileName);
                _currentFilePath = ofd.FileName;
                _participantGroup.Enabled = true;
                UpdateParticipantList();
                UpdateStatus();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to open file: {ex.Message}");
            }
        }

        // Save to current file or prompt for path
        private void SaveMenu_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_currentFilePath))
            {
                SaveAsMenu_Click(sender, e);
                return;
            }

            try
            {
                _event.ParticipantManager.SaveToFile(_currentFilePath);
                MessageBox.Show("Saved.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Save failed: {ex.Message}");
            }
        }

        // Show Save As dialog and save to chosen file
        private void SaveAsMenu_Click(object? sender, EventArgs e)
        {
            using var sfd = new SaveFileDialog();
            sfd.Filter = "Text files|*.txt|All files|*.*";
            if (sfd.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            try
            {
                _event.ParticipantManager.SaveToFile(sfd.FileName);
                _currentFilePath = sfd.FileName;
                MessageBox.Show("Saved.");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Save failed: {ex.Message}");
            }
        }

        // Confirm and close the application
        private void ExitMenu_Click(object? sender, EventArgs e)
        {
            var r = MessageBox.Show("Exit application?", "Confirm Exit", MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
            if (r == DialogResult.OK)
            {
                Close();
            }
        }
    }
}
