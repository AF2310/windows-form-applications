using System;
using System.Windows.Forms;

namespace Assignment5App
{
    // Program entry point
    internal static class Program
    {
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }
    }
}
