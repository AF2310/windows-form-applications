using System;

namespace Assignment5App
{
    // Simple address holder
    public class Address
    {
        private string _street;
        private string _city;
        private string _zipCode;
        private Countries _country;

        // Street name and number
        public string Street
        {
            get => _street;
            set => _street = value ?? string.Empty;
        }

        // City or locality
        public string City
        {
            get => _city;
            set => _city = value ?? string.Empty;
        }

        // Postal code (text)
        public string ZipCode
        {
            get => _zipCode;
            set => _zipCode = value ?? string.Empty;
        }

        // Country enum value
        public Countries Country
        {
            get => _country;
            set => _country = value;
        }

        // Default constructor with empty fields
        public Address()
        {
            _street = string.Empty;
            _city = string.Empty;
            _zipCode = string.Empty;
            _country = Countries.Afghanistan;
        }

        // Constructor with all address fields
        public Address(string street, string city, string zipCode, Countries country)
        {
            _street = street ?? string.Empty;
            _city = city ?? string.Empty;
            _zipCode = zipCode ?? string.Empty;
            _country = country;
        }

        // Return a one-line address string
        public override string ToString()
        {
            string countryName = _country.ToString().Replace('_', ' ');
            return Street + ", " + City + ", " + ZipCode + ", " + countryName;
        }
    }
}
