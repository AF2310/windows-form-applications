namespace Assignment5App
{
    // Represent a participant
    public class Participant
    {
        private string _firstName;
        private string _lastName;
        private Address _address;

        // Participant's first name
        public string FirstName
        {
            get => _firstName;
            set => _firstName = value ?? string.Empty;
        }

        // Participant's last name
        public string LastName
        {
            get => _lastName;
            set => _lastName = value ?? string.Empty;
        }

        // Participant's address
        public Address Address
        {
            get => _address;
            set => _address = value ?? new Address();
        }

        // Default constructor with empty values
        public Participant()
        {
            _firstName = string.Empty;
            _lastName = string.Empty;
            _address = new Address();
        }

        // Construct with name and address
        public Participant(string firstName, string lastName, Address address)
        {
            _firstName = firstName ?? string.Empty;
            _lastName = lastName ?? string.Empty;
            _address = address ?? new Address();
        }

        // Return a readable participant string
        public override string ToString() => FirstName + " " + LastName + ", " + Address.ToString();
    }
}
