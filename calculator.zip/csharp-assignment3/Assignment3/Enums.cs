namespace Assignment3;

// Gender used in the water intake formula.
public enum Gender
{
    Male,
    Female
}

// Activity level used in the water intake formula.
public enum ActivityLevel
{
    Low,
    Medium,
    High
}

// Unit type selected by the user in the GUI.
public enum UnitSystem
{
    Metric,
    Imperial
}