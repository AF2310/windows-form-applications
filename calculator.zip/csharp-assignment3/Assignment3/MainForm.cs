using System.Globalization;
using System.Windows.Forms;

namespace Assignment3;

// Main GUI form. Handles all user input and output.
public class MainForm : Form
{
    // Common personal input controls.
    private readonly TextBox txtName = new();
    private readonly ComboBox cmbUnit = new();
    private readonly ComboBox cmbGender = new();
    private readonly ComboBox cmbActivity = new();

    // Height/weight fields for both metric and imperial input.
    private readonly TextBox txtBirthYear = new();
    private readonly TextBox txtHeightCm = new();
    private readonly TextBox txtFeet = new();
    private readonly TextBox txtInch = new();
    private readonly TextBox txtWeightKg = new();
    private readonly TextBox txtWeightLbs = new();

    // Output labels for water intake results.
    private readonly Label lblWaterPrimary = new();
    private readonly Label lblWaterSecondary = new();
    private readonly Label lblWaterGlasses = new();

    // Input controls for retirement calculation.
    private readonly TextBox txtInitialInvestment = new();
    private readonly TextBox txtMonthlyContribution = new();
    private readonly TextBox txtAnnualInterest = new();
    private readonly TextBox txtAnnualFees = new();
    private readonly ComboBox cmbRetirementAge = new();

    // Output labels for retirement summary.
    private readonly Label lblPeriodYears = new();
    private readonly Label lblFinalBalance = new();
    private readonly Label lblTotalPaid = new();
    private readonly Label lblTotalInterest = new();
    private readonly Label lblTotalFees = new();
    private readonly Label lblGrowthRate = new();

    // Creates the form and loads default values.
    public MainForm()
    {
        Text = "Assignment 3 - Water Intake and Retirement Saving";
        Width = 980;
        Height = 760;
        StartPosition = FormStartPosition.CenterScreen;

        BuildUi();
        LoadDefaults();
        UpdateUnitInputs();
    }

    // Builds the full window layout.
    private void BuildUi()
    {
        // Root panel keeps both sections in one scrollable view.
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            ColumnCount = 1,
            RowCount = 3,
            Padding = new Padding(12)
        };

        var title = new Label
        {
            AutoSize = true,
            Text = "Assignment 3 (Grade A): Daily Water Intake + Retirement Savings",
            Font = new Font(Font, FontStyle.Bold),
            Margin = new Padding(3, 3, 3, 12)
        };

        root.Controls.Add(title);
        root.Controls.Add(BuildWaterPanel());
        root.Controls.Add(BuildRetirementPanel());

        Controls.Add(root);
    }

    // Builds the top section for water intake.
    private Control BuildWaterPanel()
    {
        var group = new GroupBox
        {
            Text = "Part 1 - Daily Water Intake Calculator",
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(10)
        };

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            AutoSize = true
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

        AddRow(layout, 0, "Name", txtName, "Birth year", txtBirthYear);
        AddRow(layout, 1, "Unit", cmbUnit, "Gender", cmbGender);
        AddRow(layout, 2, "Activity", cmbActivity, "Height (cm)", txtHeightCm);
        AddRow(layout, 3, "Height (feet)", txtFeet, "Height (inch)", txtInch);
        AddRow(layout, 4, "Weight (kg)", txtWeightKg, "Weight (lbs)", txtWeightLbs);

        var btnCalc = new Button
        {
            Text = "Calculate water intake",
            AutoSize = true,
            Margin = new Padding(3, 8, 3, 8)
        };
        btnCalc.Click += (_, _) => CalculateWaterIntake();
        layout.Controls.Add(btnCalc, 0, 5);
        layout.SetColumnSpan(btnCalc, 2);

        var outputPanel = new TableLayoutPanel
        {
            ColumnCount = 2,
            AutoSize = true,
            Dock = DockStyle.Fill,
            Margin = new Padding(3, 8, 3, 0)
        };

        outputPanel.Controls.Add(new Label { Text = "Recommended amount", AutoSize = true }, 0, 0);
        outputPanel.Controls.Add(lblWaterPrimary, 1, 0);

        outputPanel.Controls.Add(new Label { Text = "Converted amount", AutoSize = true }, 0, 1);
        outputPanel.Controls.Add(lblWaterSecondary, 1, 1);

        outputPanel.Controls.Add(new Label { Text = "Glasses (240 ml)", AutoSize = true }, 0, 2);
        outputPanel.Controls.Add(lblWaterGlasses, 1, 2);

        layout.Controls.Add(outputPanel, 0, 6);
        layout.SetColumnSpan(outputPanel, 4);

        group.Controls.Add(layout);
        return group;
    }

    // Builds the bottom section for retirement savings.
    private Control BuildRetirementPanel()
    {
        var group = new GroupBox
        {
            Text = "Part 2 - Retirement Saving Calculator",
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(10)
        };

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            AutoSize = true
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

        AddRow(layout, 0, "Initial investment", txtInitialInvestment, "Monthly contribution", txtMonthlyContribution);
        AddRow(layout, 1, "Annual interest %", txtAnnualInterest, "Annual fees %", txtAnnualFees);
        AddRow(layout, 2, "Retirement age", cmbRetirementAge, "", new Label());

        var btnCalc = new Button
        {
            Text = "Calculate retirement savings",
            AutoSize = true,
            Margin = new Padding(3, 8, 3, 8)
        };
        btnCalc.Click += (_, _) => CalculateRetirementSavings();
        layout.Controls.Add(btnCalc, 0, 3);
        layout.SetColumnSpan(btnCalc, 2);

        var outputPanel = new TableLayoutPanel
        {
            ColumnCount = 2,
            AutoSize = true,
            Dock = DockStyle.Fill,
            Margin = new Padding(3, 8, 3, 0)
        };

        outputPanel.Controls.Add(new Label { Text = "Period (years)", AutoSize = true }, 0, 0);
        outputPanel.Controls.Add(lblPeriodYears, 1, 0);

        outputPanel.Controls.Add(new Label { Text = "Final balance", AutoSize = true }, 0, 1);
        outputPanel.Controls.Add(lblFinalBalance, 1, 1);

        outputPanel.Controls.Add(new Label { Text = "Total amount paid", AutoSize = true }, 0, 2);
        outputPanel.Controls.Add(lblTotalPaid, 1, 2);

        outputPanel.Controls.Add(new Label { Text = "Total interest", AutoSize = true }, 0, 3);
        outputPanel.Controls.Add(lblTotalInterest, 1, 3);

        outputPanel.Controls.Add(new Label { Text = "Total fees", AutoSize = true }, 0, 4);
        outputPanel.Controls.Add(lblTotalFees, 1, 4);

        outputPanel.Controls.Add(new Label { Text = "Growth rate", AutoSize = true }, 0, 5);
        outputPanel.Controls.Add(lblGrowthRate, 1, 5);

        layout.Controls.Add(outputPanel, 0, 4);
        layout.SetColumnSpan(outputPanel, 4);

        group.Controls.Add(layout);
        return group;
    }

    // Adds one input row with two labels and two controls.
    private static void AddRow(TableLayoutPanel panel, int row, string label1, Control control1, string label2, Control control2)
    {
        panel.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        panel.Controls.Add(new Label { Text = label1, AutoSize = true, Anchor = AnchorStyles.Left }, 0, row);
        control1.Width = 170;
        panel.Controls.Add(control1, 1, row);

        panel.Controls.Add(new Label { Text = label2, AutoSize = true, Anchor = AnchorStyles.Left }, 2, row);
        control2.Width = 170;
        panel.Controls.Add(control2, 3, row);
    }

    // Sets default values so user can test quickly.
    private void LoadDefaults()
    {
        // Combo boxes are filled from enums to avoid typing errors.
        cmbUnit.DataSource = Enum.GetValues(typeof(UnitSystem));
        cmbUnit.SelectedIndexChanged += (_, _) => UpdateUnitInputs();
        cmbUnit.SelectedItem = UnitSystem.Metric;

        cmbGender.DataSource = Enum.GetValues(typeof(Gender));
        cmbGender.SelectedItem = Gender.Male;

        cmbActivity.DataSource = Enum.GetValues(typeof(ActivityLevel));
        cmbActivity.SelectedItem = ActivityLevel.Medium;

        for (int age = 62; age <= 70; age++)
        {
            cmbRetirementAge.Items.Add(age);
        }
        cmbRetirementAge.SelectedIndex = 3;

        txtBirthYear.Text = "1995";
        txtHeightCm.Text = "175";
        txtWeightKg.Text = "70";
        txtFeet.Text = "5";
        txtInch.Text = "9";
        txtWeightLbs.Text = "154";

        txtInitialInvestment.Text = "10000";
        txtMonthlyContribution.Text = "2000";
        txtAnnualInterest.Text = "6";
        txtAnnualFees.Text = "0";

        lblWaterPrimary.AutoSize = true;
        lblWaterSecondary.AutoSize = true;
        lblWaterGlasses.AutoSize = true;
        lblPeriodYears.AutoSize = true;
        lblFinalBalance.AutoSize = true;
        lblTotalPaid.AutoSize = true;
        lblTotalInterest.AutoSize = true;
        lblTotalFees.AutoSize = true;
        lblGrowthRate.AutoSize = true;
    }

    // Shows correct input boxes for selected unit.
    private void UpdateUnitInputs()
    {
        UnitSystem unit = (UnitSystem)cmbUnit.SelectedItem!;
        bool metric = unit == UnitSystem.Metric;

        txtHeightCm.Enabled = metric;
        txtWeightKg.Enabled = metric;

        txtFeet.Enabled = !metric;
        txtInch.Enabled = !metric;
        txtWeightLbs.Enabled = !metric;
    }

    // Reads person data and shows water result.
    private void CalculateWaterIntake()
    {
        // Stop early if input is invalid.
        if (!TryReadPersonFromUi(out Person person))
        {
            return;
        }

        var calculator = new WaterIntakeCalculator(person);

        double milliliters = calculator.CalculateMilliliters();
        double ounces = calculator.CalculateOunces();
        double glasses = calculator.CalculateGlasses();

        if (person.GetUnitSystem() == UnitSystem.Metric)
        {
            lblWaterPrimary.Text = $"{milliliters:N0} ml";
            lblWaterSecondary.Text = $"{ounces:N1} oz";
        }
        else
        {
            lblWaterPrimary.Text = $"{ounces:N1} oz";
            lblWaterSecondary.Text = $"{milliliters:N0} ml";
        }

        lblWaterGlasses.Text = $"{glasses:N1} glasses";
    }

    // Reads values and shows retirement result.
    private void CalculateRetirementSavings()
    {
        // Person data is shared with retirement logic (age info).
        if (!TryReadPersonFromUi(out Person person))
        {
            return;
        }

        if (!TryReadNonNegativeDouble(txtInitialInvestment.Text, out double initialInvestment))
        {
            ShowError("Initial investment must be a valid number (0 or more).");
            return;
        }

        if (!TryReadNonNegativeDouble(txtMonthlyContribution.Text, out double monthlyContribution))
        {
            ShowError("Monthly contribution must be a valid number (0 or more).");
            return;
        }

        if (!TryReadNonNegativeDouble(txtAnnualInterest.Text, out double annualInterest))
        {
            ShowError("Annual interest must be a valid number (0 or more).");
            return;
        }

        if (!TryReadNonNegativeDouble(txtAnnualFees.Text, out double annualFees))
        {
            ShowError("Annual fees must be a valid number (0 or more).");
            return;
        }

        if (cmbRetirementAge.SelectedItem is not int retirementAge)
        {
            ShowError("Please select a retirement age from the list.");
            return;
        }

        var calculator = new RetirementSavingCalculator();
        calculator.SetInitialInvestment(initialInvestment);
        calculator.SetMonthlyContribution(monthlyContribution);
        calculator.SetAnnualInterestRate(annualInterest);
        calculator.SetAnnualFeeRate(annualFees);

        if (!calculator.Calculate(person, retirementAge))
        {
            ShowError("Retirement age must be greater than current age.");
            return;
        }

        lblPeriodYears.Text = calculator.GetPeriodInYears().ToString(CultureInfo.InvariantCulture);
        lblFinalBalance.Text = $"{calculator.GetFinalBalance():C2}";
        lblTotalPaid.Text = $"{calculator.GetTotalAmountPaid():C2}";
        lblTotalInterest.Text = $"{calculator.GetTotalInterest():C2}";
        lblTotalFees.Text = $"{calculator.GetTotalFees():C2}";
        lblGrowthRate.Text = $"{calculator.GetGrowthRate():N2} %";
    }

    // Reads and validates person values from GUI controls.
    private bool TryReadPersonFromUi(out Person person)
    {
        // Create a fresh person object each click.
        person = new Person();
        person.SetName(txtName.Text);

        if (!int.TryParse(txtBirthYear.Text, out int birthYear))
        {
            ShowError("Birth year must be a whole number.");
            return false;
        }

        int thisYear = DateTime.Now.Year;
        if (birthYear < 1900 || birthYear > thisYear)
        {
            ShowError($"Birth year must be between 1900 and {thisYear}.");
            return false;
        }

        person.SetBirthYear(birthYear);
        person.SetGender((Gender)cmbGender.SelectedItem!);
        person.SetActivityLevel((ActivityLevel)cmbActivity.SelectedItem!);

        UnitSystem unit = (UnitSystem)cmbUnit.SelectedItem!;
        person.SetUnitSystem(unit);

        // Read only the active fields for current unit mode.
        if (unit == UnitSystem.Metric)
        {
            if (!TryReadPositiveDouble(txtHeightCm.Text, out double heightCm))
            {
                ShowError("Height (cm) must be a positive number.");
                return false;
            }

            if (!TryReadPositiveDouble(txtWeightKg.Text, out double weightKg))
            {
                ShowError("Weight (kg) must be a positive number.");
                return false;
            }

            person.SetHeightCm(heightCm);
            person.SetWeightKg(weightKg);
        }
        else
        {
            if (!int.TryParse(txtFeet.Text, out int feet) || feet < 0)
            {
                ShowError("Height (feet) must be a whole number, 0 or more.");
                return false;
            }

            if (!TryReadNonNegativeDouble(txtInch.Text, out double inches))
            {
                ShowError("Height (inch) must be a number, 0 or more.");
                return false;
            }

            if (feet == 0 && Math.Abs(inches) < 0.0001)
            {
                ShowError("Height must be greater than zero.");
                return false;
            }

            if (!TryReadPositiveDouble(txtWeightLbs.Text, out double weightLbs))
            {
                ShowError("Weight (lbs) must be a positive number.");
                return false;
            }

            person.SetHeightFeet(feet);
            person.SetHeightInches(inches);
            person.SetWeightLbs(weightLbs);
        }

        return true;
    }

    // Helper for positive numeric input.
    private static bool TryReadPositiveDouble(string text, out double value)
    {
        // TryParse avoids crashes when text is not numeric.
        bool ok = double.TryParse(text, out value);
        return ok && value > 0;
    }

    // Helper for zero or positive numeric input.
    private static bool TryReadNonNegativeDouble(string text, out double value)
    {
        bool ok = double.TryParse(text, out value);
        return ok && value >= 0;
    }

    // Shows one warning message for bad input.
    private void ShowError(string message)
    {
        MessageBox.Show(message, "Input error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}