namespace Assignment3;

// Calculates savings growth until retirement age.
public class RetirementSavingCalculator
{
    // Inputs from the GUI.
    private double initialInvestment;
    private double monthlyContribution;
    private double annualInterestRate;
    private double annualFeeRate;
    private int periodInYears;

    // Outputs shown to the user.
    private double finalBalance;
    private double totalInterest;
    private double totalFees;
    private double totalAmountPaid;
    private double growthRate;

    // Sets starting balance before monthly saving begins.
    public void SetInitialInvestment(double value)
    {
        initialInvestment = value;
    }

    // Sets monthly saving amount.
    public void SetMonthlyContribution(double value)
    {
        monthlyContribution = value;
    }

    // Sets yearly interest rate in percent.
    public void SetAnnualInterestRate(double value)
    {
        annualInterestRate = value;
    }

    // Sets yearly fee rate in percent.
    public void SetAnnualFeeRate(double value)
    {
        annualFeeRate = value;
    }

    // Runs month by month calculation and stores summary values.
    public bool Calculate(Person person, int retirementAge)
    {
        // Retirement period is target age minus current age.
        periodInYears = retirementAge - person.GetAge();
        if (periodInYears <= 0)
        {
            return false;
        }

        // Convert year values to month values.
        int months = periodInYears * 12;
        double monthlyInterestRate = (annualInterestRate / 100.0) / 12.0;
        double monthlyFeeRate = (annualFeeRate / 100.0) / 12.0;

        double balance = initialInvestment + monthlyContribution;
        totalInterest = 0;
        totalFees = 0;

        // Month by month loop based on assignment model.
        for (int month = 1; month <= months; month++)
        {
            double interest = monthlyInterestRate * balance;
            double fees = monthlyFeeRate * balance;

            balance += interest - fees + monthlyContribution;
            totalInterest += interest;
            totalFees += fees;
        }

        finalBalance = balance;
        // Total paid is what user put in directly.
        totalAmountPaid = initialInvestment + (months * monthlyContribution);
        // Growth rate compares total interest to final balance.
        growthRate = finalBalance > 0 ? (totalInterest / finalBalance) * 100.0 : 0;

        return true;
    }

    // Returns how many years are used in the calculation.
    public int GetPeriodInYears()
    {
        return periodInYears;
    }

    // Returns final balance when calculation is done.
    public double GetFinalBalance()
    {
        return finalBalance;
    }

    // Returns total earned interest.
    public double GetTotalInterest()
    {
        return totalInterest;
    }

    // Returns total paid fees.
    public double GetTotalFees()
    {
        return totalFees;
    }

    // Returns total money user paid in.
    public double GetTotalAmountPaid()
    {
        return totalAmountPaid;
    }

    // Returns growth rate in percent.
    public double GetGrowthRate()
    {
        return growthRate;
    }
}