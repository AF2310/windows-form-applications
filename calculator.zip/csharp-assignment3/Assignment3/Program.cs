﻿namespace Assignment3;

// Starts the Windows Forms app.
internal static class Program
{
    [STAThread]
    // Entry point for the whole program.
    private static void Main()
    {
        ApplicationConfiguration.Initialize();
        Application.Run(new MainForm());
    }
}