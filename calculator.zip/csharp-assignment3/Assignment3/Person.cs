namespace Assignment3;

// Stores user input data for both calculators.
public class Person
{
    // Basic identity and profile choices.
    private string name = string.Empty;
    private int birthYear;
    private Gender gender;
    private ActivityLevel activityLevel;
    private UnitSystem unitSystem;

    // Height values are stored depending on chosen unit.
    private double heightCm;
    private int heightFeet;
    private double heightInches;

    // Weight values are stored depending on chosen unit.
    private double weightKg;
    private double weightLbs;

    // Saves name from GUI after trimming spaces.
    public void SetName(string value)
    {
        name = value?.Trim() ?? string.Empty;
    }

    public string GetName()
    {
        return name;
    }

    // Saves birth year used to calculate age.
    public void SetBirthYear(int year)
    {
        birthYear = year;
    }

    public int GetBirthYear()
    {
        return birthYear;
    }

    // Returns age based on current year.
    public int GetAge()
    {
        return DateTime.Now.Year - birthYear;
    }

    // Saves selected gender.
    public void SetGender(Gender value)
    {
        gender = value;
    }

    public Gender GetGender()
    {
        return gender;
    }

    // Saves selected activity level.
    public void SetActivityLevel(ActivityLevel value)
    {
        activityLevel = value;
    }

    public ActivityLevel GetActivityLevel()
    {
        return activityLevel;
    }

    // Saves selected unit system.
    public void SetUnitSystem(UnitSystem value)
    {
        unitSystem = value;
    }

    public UnitSystem GetUnitSystem()
    {
        return unitSystem;
    }

    // Saves metric height.
    public void SetHeightCm(double value)
    {
        heightCm = value;
    }

    // Saves imperial feet part.
    public void SetHeightFeet(int value)
    {
        heightFeet = value;
    }

    // Saves imperial inch part.
    public void SetHeightInches(double value)
    {
        heightInches = value;
    }

    // Saves metric weight.
    public void SetWeightKg(double value)
    {
        weightKg = value;
    }

    // Saves imperial weight.
    public void SetWeightLbs(double value)
    {
        weightLbs = value;
    }

    // Returns height in cm no matter which unit user selected.
    public double GetHeightInCm()
    {
        if (unitSystem == UnitSystem.Metric)
        {
            return heightCm;
        }

        double totalInches = heightFeet * 12.0 + heightInches;
        return totalInches * 2.54;
    }

    // Returns weight in kg no matter which unit user selected.
    public double GetWeightInKg()
    {
        if (unitSystem == UnitSystem.Metric)
        {
            return weightKg;
        }

        return weightLbs * 0.453592;
    }
}