namespace Assignment3;

// Calculates daily water recommendation for one person.
public class WaterIntakeCalculator
{
    // Person object with all input values.
    private Person person;

    // Creates calculator for one person.
    public WaterIntakeCalculator(Person person)
    {
        this.person = person;
    }

    // Allows changing person later if needed.
    public void SetPerson(Person value)
    {
        person = value;
    }

    // Calculates final water intake in milliliters.
    public double CalculateMilliliters()
    {
        // Base rule: 33 ml per kg.
        double baseIntake = 33.0 * person.GetWeightInKg();

        // Multiply all adjustment factors.
        double totalFactor = GetGenderFactor()
                             * GetAgeFactor()
                             * GetHeightFactor()
                             * GetActivityFactor();

        return baseIntake * totalFactor;
    }

    // Converts milliliters result to ounces.
    public double CalculateOunces()
    {
        return CalculateMilliliters() * 0.033814;
    }

    // Converts milliliters result to glasses of 240 ml.
    public double CalculateGlasses()
    {
        return CalculateMilliliters() / 240.0;
    }

    // Gets gender factor from assignment rules.
    private double GetGenderFactor()
    {
        return person.GetGender() == Gender.Male ? 1.1 : 0.9;
    }

    // Gets age factor from assignment rules.
    private double GetAgeFactor()
    {
        int age = person.GetAge();

        if (age < 30)
        {
            return 1.1;
        }

        if (age > 55)
        {
            return 0.9;
        }

        return 1.0;
    }

    // Gets height factor from assignment rules.
    private double GetHeightFactor()
    {
        double heightCm = person.GetHeightInCm();

        if (heightCm > 175)
        {
            return 1.05;
        }

        if (heightCm < 160)
        {
            return 0.95;
        }

        return 1.0;
    }

    // Gets activity factor from assignment rules.
    private double GetActivityFactor()
    {
        ActivityLevel activity = person.GetActivityLevel();

        if (activity == ActivityLevel.Medium)
        {
            return 1.2;
        }

        if (activity == ActivityLevel.High)
        {
            return 1.5;
        }

        return 1.0;
    }
}